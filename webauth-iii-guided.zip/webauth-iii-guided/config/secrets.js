module.exports = {
  jwtSecret: process.env.JWT_SECRET || "add a .env file with this value in it"
};
