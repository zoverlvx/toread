# Web DB IV

## A good data model...

- captures all the data the system needs
- captures only the data the system needs
- reflects reality
- is flexible, can evolve with the system
- guarantees data integrity
- is driven by the way the data will be used

## Components

- entities === resources -> tables
- attributes -> columns
- relationships === sub-routes (/recipes/:id/ingredients) -> Foreign Keys

## Workflow

- identify entities -> squares on paper
- identify attributes -> bulleted list
- identify relationships -> lines joining the squares

### Tracks

- id, pk, integer, auto-incrementing
- name, string(128), unique, required

## Relationships

- one to one -> one to zero or one
- one to many <- most common one
- many to many (smoke and mirrors, an illusion) <- a third table

## Mantras

- for a many to many we need: a third table
- the most important tools for data modelling: pen & paper and ears
- (one to many) relationships translate to: FK (Foreign Keys) NOTE TYPES OF FK AND PM MUST MATCH
- where does a foreign key go? : on the many side

### todays guided project steps

- thoroughly read through the clients requirements with a pen and paper
  - note the nouns (entities -> tables -> bolded words)
  - each table map out it attributes
  - each table map it relations (FK)
- create you migrations (one or many files)
- create some seeds for your tables (must go in the proper order following your constraints -> prepend our seed names with numbers to insure the order they run in)
- create the 5 helper methods that the client would like
- good folder/file structure utilizing routers and import/exports accordingly
